package com.example.simplifiedgoogleform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplifiedgoogleformApplicationTests {

	@Test
	void contextLoads() {
	}

}
