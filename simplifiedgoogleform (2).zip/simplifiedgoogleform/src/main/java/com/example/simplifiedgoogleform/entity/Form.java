package com.example.simplifiedgoogleform.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "forms")
public class Form {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // True = published, False = not published
    private boolean published;

    // The final address for the form's "Submit" action
    private String submitAddress;

    // A Form can have many Fields
    @OneToMany(mappedBy = "form", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FormField> fields = new ArrayList<>();

    public Form() {}

    public Form(String name, boolean published, String submitAddress) {
        this.name = name;
        this.published = published;
        this.submitAddress = submitAddress;
    }

    // Getters & Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public boolean isPublished() {
        return published;
    }
    public void setPublished(boolean published) {
        this.published = published;
    }

    public String getSubmitAddress() {
        return submitAddress;
    }
    public void setSubmitAddress(String submitAddress) {
        this.submitAddress = submitAddress;
    }

    public List<FormField> getFields() {
        return fields;
    }

    /**
     * Revised setter to handle field replacement correctly.
     */
    public void setFields(List<FormField> newFields) {
        // Clear existing collection (triggers orphanRemoval for old children)
        this.fields.clear();

        if (newFields == null) {
            return;
        }

        // Add the new fields & link them back
        for (FormField field : newFields) {
            field.setForm(this);  // Ensures parent is set
            this.fields.add(field);
        }
    }
}
