package com.example.simplifiedgoogleform.dto;

public class FieldDTO {
    private Long id;
    private String fieldName;
    private String label;
    private String fieldType;
    private String defaultValue;

    public FieldDTO() {}

    public FieldDTO(Long id, String fieldName, String label, String fieldType, String defaultValue) {
        this.id = id;
        this.fieldName = fieldName;
        this.label = label;
        this.fieldType = fieldType;
        this.defaultValue = defaultValue;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFieldName() { return fieldName; }
    public void setFieldName(String fieldName) { this.fieldName = fieldName; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public String getFieldType() { return fieldType; }
    public void setFieldType(String fieldType) { this.fieldType = fieldType; }

    public String getDefaultValue() { return defaultValue; }
    public void setDefaultValue(String defaultValue) { this.defaultValue = defaultValue; }
}
