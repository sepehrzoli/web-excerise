package com.example.simplifiedgoogleform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplifiedgoogleformApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplifiedgoogleformApplication.class, args);
	}

}
