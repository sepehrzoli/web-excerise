package com.example.simplifiedgoogleform.repository;

import com.example.simplifiedgoogleform.entity.FormField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FormFieldRepository extends JpaRepository<FormField, Long> {
    // Additional queries can go here
}
