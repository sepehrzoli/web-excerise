package com.example.simplifiedgoogleform.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "fields")
public class FormField {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fieldName;

    private String label;

    private String fieldType;

    private String defaultValue;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "form_id")
    private Form form;

    public FormField() {
    }

    public FormField(String fieldName, String label, String fieldType, String defaultValue) {
        this.fieldName = fieldName;
        this.label = label;
        this.fieldType = fieldType;
        this.defaultValue = defaultValue;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getFieldName() {
        return fieldName;
    }
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }

    public String getFieldType() {
        return fieldType;
    }
    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    public String getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public Form getForm() {
        return form;
    }
    public void setForm(Form form) {
        this.form = form;
    }
}
