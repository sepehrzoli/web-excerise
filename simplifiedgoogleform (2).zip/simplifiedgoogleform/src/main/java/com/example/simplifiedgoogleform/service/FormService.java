package com.example.simplifiedgoogleform.service;

import com.example.simplifiedgoogleform.dto.FieldDTO;
import com.example.simplifiedgoogleform.dto.FormDTO;
import com.example.simplifiedgoogleform.entity.Form;
import com.example.simplifiedgoogleform.entity.FormField;
import com.example.simplifiedgoogleform.exception.FormNotFoundException;
import com.example.simplifiedgoogleform.repository.FormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FormService {

    @Autowired
    private FormRepository formRepository;

    // -----------------------------
    // Convert Helpers
    // -----------------------------

    private FormDTO convertToDTO(Form form) {
        FormDTO dto = new FormDTO();
        dto.setId(form.getId());
        dto.setName(form.getName());
        dto.setPublished(form.isPublished());
        dto.setSubmitAddress(form.getSubmitAddress());

        List<FieldDTO> fields = form.getFields().stream()
                .map(ff -> new FieldDTO(ff.getId(),
                        ff.getFieldName(),
                        ff.getLabel(),
                        ff.getFieldType(),
                        ff.getDefaultValue()))
                .collect(Collectors.toList());
        dto.setFields(fields);
        return dto;
    }

    private Form convertToEntity(FormDTO dto) {
        Form form = new Form();
        form.setName(dto.getName());
        form.setPublished(dto.isPublished());
        form.setSubmitAddress(dto.getSubmitAddress());

        if (dto.getFields() != null) {
            List<FormField> fieldList = dto.getFields().stream()
                    .map(fdto -> {
                        FormField f = new FormField();
                        f.setFieldName(fdto.getFieldName());
                        f.setLabel(fdto.getLabel());
                        f.setFieldType(fdto.getFieldType());
                        f.setDefaultValue(fdto.getDefaultValue());
                        return f;
                    })
                    .collect(Collectors.toList());
            form.setFields(fieldList);
        }
        return form;
    }

    // -----------------------------
    // CRUD Methods
    // -----------------------------

    public List<FormDTO> getAllForms() {
        return formRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public FormDTO createForm(FormDTO formDTO) {
        Form form = convertToEntity(formDTO);
        // Link the new fields to the form
        if (form.getFields() != null) {
            form.getFields().forEach(ff -> ff.setForm(form));
        }
        Form saved = formRepository.save(form);
        return convertToDTO(saved);
    }

    public FormDTO getFormById(Long id) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new FormNotFoundException("Form not found with id " + id));
        return convertToDTO(form);
    }

    public FormDTO updateForm(Long id, FormDTO formDTO) {
        Form existing = formRepository.findById(id)
                .orElseThrow(() -> new FormNotFoundException("Form not found with id " + id));

        existing.setName(formDTO.getName());
        existing.setPublished(formDTO.isPublished());
        existing.setSubmitAddress(formDTO.getSubmitAddress());
        formRepository.save(existing);

        return convertToDTO(existing);
    }

    public void deleteForm(Long id) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new FormNotFoundException("Form not found with id " + id));
        formRepository.delete(form);
    }

    // -----------------------------
    // Field Operations
    // -----------------------------

    public List<FieldDTO> getFieldsByFormId(Long formId) {
        Form form = formRepository.findById(formId)
                .orElseThrow(() -> new FormNotFoundException("Form not found with id " + formId));

        return form.getFields().stream()
                .map(ff -> new FieldDTO(ff.getId(), ff.getFieldName(), ff.getLabel(), ff.getFieldType(), ff.getDefaultValue()))
                .collect(Collectors.toList());
    }

    /**
     * Replace old fields with the new list of fields (orphanRemoval friendly).
     *
     * Use @Transactional to ensure everything happens in one atomic DB operation.
     */
    @Transactional
    public List<FieldDTO> updateFields(Long formId, List<FieldDTO> fieldDTOs) {
        // 1) Find the form
        Form form = formRepository.findById(formId)
                .orElseThrow(() -> new FormNotFoundException("Form not found with id " + formId));

        // 2) Create new child entities
        List<FormField> newFields = fieldDTOs.stream().map(fdto -> {
            FormField ff = new FormField();
            ff.setFieldName(fdto.getFieldName());
            ff.setLabel(fdto.getLabel());
            ff.setFieldType(fdto.getFieldType());
            ff.setDefaultValue(fdto.getDefaultValue());
            // Linking is handled in setFields
            return ff;
        }).collect(Collectors.toList());

        // 3) Set the new fields, which clears old fields and adds new ones
        form.setFields(newFields);

        // 4) Save once
        formRepository.save(form);

        // 5) Convert to DTO and return
        return form.getFields().stream()
                .map(ff -> new FieldDTO(ff.getId(),
                        ff.getFieldName(),
                        ff.getLabel(),
                        ff.getFieldType(),
                        ff.getDefaultValue()))
                .collect(Collectors.toList());
    }

    public FormDTO togglePublishStatus(Long id) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new FormNotFoundException("Form not found with id " + id));
        form.setPublished(!form.isPublished());
        formRepository.save(form);
        return convertToDTO(form);
    }

    public List<FormDTO> getPublishedForms() {
        return formRepository.findAll().stream()
                .filter(Form::isPublished)
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
}
